# DI Weather Station - Hurricane Polo Follow-Up Scan

**Scan executed:** 8:30 PM ET cycle  
**Live retrieval cutoff:** 00:35:45 UTC September 26 / 8:35:45 PM ET September 25, 2026  
**Locked comparison baseline:** 20:46 UTC / 4:46 PM ET September 25, 2026

## Executive delta

Scenario A remains the controlling source-supported scenario.

The most important change is that the 155-kt intensity is no longer resting primarily on satellite estimates: fresh NOAA aircraft/UAS evidence supports 155 kt. The 900-mb baseline pressure was not confirmed. NHC Advisory 21 reset the official pressure to 913 mb, with a 15-nmi eye and motion 275 degrees at 9 kt.

A second material change is structural: aircraft reported possible early signs of an eyewall replacement cycle (ERC). NHC said it was not yet having an apparent impact on Polo but could produce intensity fluctuations over the next 24 hours. That materially changes the baseline structural assumption, which relied on the 0905Z microwave pass showing no concentric eyewall.

## Post-cutoff evidence chain

- **NHC Advisory/Discussion 21 - 21:00Z Sep 25.** 17.2N, 109.2W; 155 kt; 913 mb; eye 15 n mi; W 275 degrees / 9 kt. Aircraft: 165-kt flight-level wind NE quadrant; UAS >200 kt below 500 m, experimentally corresponding to about 150-155 kt at 10 m. **SOURCE-DERIVED / OFFICIAL**
- **NOAA3 VDM mission WD - through 22:11:02Z.** Lowest decoded VDM pressure 914 mb; maximum decoded flight-level wind 154 kt. **SOURCE-DERIVED / PRELIMINARY**
- **NOAA3 dropsondes - through 23:50Z.** Lowest surface pressure 913 mb; max significant-level wind 178 kt; highest near-surface wind 167 kt. Short-duration sonde measurements, not 1-minute sustained winds. **SOURCE-DERIVED / PRELIMINARY**
- **NOAA3 HDOB - through 00:13:30Z Sep 26.** Lowest processed extrapolated pressure 908.5 mb; max 30-sec flight-level wind 151 kt; no SFMR value displayed. Decoder warning preserved: extrapolated pressures can be inaccurate. **SOURCE-DERIVED / PRELIMINARY**

The post-21Z research data suggest continued extreme inner-core conditions and pressure fluctuation, but do not justify replacing NHC's official 155-kt / 913-mb analysis with 908.5 mb or a higher sustained-wind value.

## 1. What materially changed

Fresh aircraft data closed the baseline's largest immediate observation gap. The 155-kt intensity is directly supported; official pressure changed from 900 to 913 mb; the eye changed from 20 to 15 n mi; observed translation decreased from 10 to 9 kt; and heading changed from 270 to 275 degrees.

The wind field also redistributed. From Advisory 20 to 21, 64-kt radii contracted by roughly 5 n mi in each quadrant, while the 34-kt radius expanded 100->120 n mi NE and 80->90 n mi SW. The public-advisory maximum tropical-storm-force extent increased from 115 to 140 miles, while maximum hurricane-force extent decreased from 40 to 35 miles.

## 2. What did not change

Polo remains a 155-kt Category 5 hurricane in the latest completed package; the expected steering evolution remains NW -> N -> NE around the ridge toward Baja; weakening is still expected as ocean heat content decreases and shear increases; and the Baja rainfall envelope remains 4-8 inches with maxima of 10 inches. No coastal watches or warnings were in effect at 21Z.

## 3. 155 kt / 900 mb baseline determination

**Wind: CONFIRMED / MAINTAINED.** Fresh aircraft and UAS observations support NHC's continued 155-kt analysis.

**Pressure: SUPERSEDED, not confirmed.** The official aircraft-supported 21Z value is 913 mb, not 900 mb. Subsequent raw research observations show pressures fluctuating through the low 910s and an extrapolated HDOB minimum of 908.5 mb, but that preliminary number should not replace the official analysis.

**DI WEATHER INFERENCE:** Extreme-intensity plateau with changing inner-core pressure/structure, not evidence of a new sustained-wind intensification beyond 155 kt.

## 4. ERC / structural-change evidence

**Material new evidence: YES. Hard ERC trigger: NOT YET.**

NHC reported that aircraft data may be detecting the beginning of an ERC. The DI trigger defined in the baseline requires a concentric eyewall or double wind maximum. No post-cutoff authoritative microwave product or explicit double-wind-max declaration was recovered that satisfied the harder criterion.

**Status: ERC WATCH / PARTIAL CONDITION.** The prior "no immediate ERC" assumption can no longer be carried forward unchanged.

## 5. Track, speed and turn timing

Observed motion changed modestly: W 270 degrees / 10 kt -> W 275 degrees / 9 kt. That does not satisfy the DI slowdown trigger of <=7 kt on two successive fixes.

At the forecast level, NHC said track adjustments were small and anticipated future forward motion was slightly faster than in Advisory 20. The NW->N turn remains expected over the weekend, followed by the NE turn early next week. Model spread increased after roughly 72 hours, lowering longer-range track confidence. No source-supported >=50-n-mi right/east displacement trigger was identified at this scan.

## 6. Geographic corridor update

- **Socorro / offshore:** remains the immediate high-end wind and marine corridor.
- **Cabo / Los Cabos:** still does not become the principal direct-wind corridor merely because Polo is approaching Baja. Swell, coastal flooding, rainfall and logistical effects remain relevant.
- **La Paz / Loreto / central-eastern Baja:** remains the strongest emerging land-compound corridor under the present track architecture.
- **Gulf of California / western mainland Mexico:** remains a later-horizon corridor.

**UNRESOLVED:** A new location-by-location Advisory 21 probability table was not promoted because live text endpoints were returning inconsistent/stale advisory labels. Mixing an older table into a 21Z delta would violate source-lock.

## 7. Rainfall / terrain / coastal water

**Rainfall trigger: NOT FIRED.** The official Baja envelope remains 4-8 inches, maximum 10 inches, with life-threatening flooding/mudslides possible in steep terrain. NHC emphasizes onset over Baja late Sunday into Monday.

**Coastal-water trigger: NOT FIRED.** Swells, dangerous surf, rip currents and coastal flooding remain in the official forecast, but no verified Polo-specific tide anomaly, measured inundation or coastal-residence observation was recovered after the baseline cutoff.

## 8. DI decision-trigger state

- Track displacement >=50 n mi right/east: **NO**
- Translation <=7 kt on two successive fixes: **NO**
- Intensity deviation >=15 kt: **NO**
- ERC / double-wind-max condition: **WATCH / PARTIAL**
- Rainfall >10 in / major terrain-axis escalation: **NO**
- Verified coastal-water anomaly/inundation: **NO / UNRESOLVED**
- CFRI >=25-point central change or credible bound >=175: **NOT COMPUTABLE from new evidence**
- Any Baja tropical watch/warning: **NO at 21Z**, but NHC moved possible watch issuance from "as early as Saturday" to "as soon as tonight."

## 9. Scenario state

**DI WEATHER INFERENCE: Scenario A remains controlling.**

The possible ERC is a Scenario-C-type weakening signal. The persistent extreme core, slightly slower observed motion and accelerated Baja watch posture are Scenario-B-side concerns. Neither had accumulated enough evidence to replace the central track/intensity evolution.

NHC's new forecast still carries Polo from 155 kt at 21Z -> 150 kt at 06Z -> 140 kt at 18Z Saturday -> 125 kt at 06Z Sunday while curving northward toward Baja.

## 10. Forecast-failure test

**Central forecast failure: NO.**

Polo had not exceeded the 155-kt plateau in an authoritative 1-minute intensity analysis; weakening timing had not yet reached the principal test window; and the expected turn was not yet overdue.

One baseline assumption weakened materially: "no immediate new ERC." Fresh aircraft observations made an ERC plausible. That is an assumption failure/watch item, not yet a failure of the central Scenario A forecast.

## FTA / SMRB / SDRL / CFRI

**NO RECALCULATION AUTHORIZED BY THE EVIDENCE.**

Fresh reconnaissance materially improves the physical-intensity state, but does not provide the missing coastal-water residence / inundation evidence that dominates SDRL. Rainfall did not exceed the existing envelope and translation did not meet the slowdown trigger. Recomputing CFRI numerically would introduce unsupported precision.

The prior CFRI values remain locked historical baseline values, not updated outputs. **+48 h remains UNRESOLVED.**

## Executive close

- **Executive State:** SOURCE-SUPPORTED EXTREME CAT-5 CORE; Scenario A intact; structural transition watch elevated.
- **What Changed:** Fresh aircraft/UAS/dropsonde evidence; 900->913 mb official pressure; 20->15 n-mi eye; 10->9 kt observed motion; possible ERC; broader tropical-storm wind envelope; Baja watch timing advanced to potentially tonight.
- **Highest-Risk Corridor:** Immediate physical/marine: Polo core / Socorro-offshore. Emerging land-compound: central/eastern Baja California Sur.
- **Trigger Status:** No defined hard DI recalculation trigger fully fired. ERC on WATCH. Baja watch/warning trigger pending.
- **Scenario State:** A - CENTRAL, with competing early B/C indicators insufficient for scenario replacement.
- **Biggest Uncertainty:** Whether the early ERC signal becomes a genuine eyewall replacement and how it interacts with Polo's turn/translation speed approaching Baja.
- **Highest-Value Next Observation:** Fresh microwave/recon structural confirmation of eyewall state, paired with the next center fix and quality-controlled surface-wind data.
- **Next Decision Trigger:** Any Baja watch/warning before the next cycle; otherwise NHC Advisory/Discussion 22 at 03Z September 26.
- **Next Recalculation Time:** Immediate on an intervening watch/warning, confirmed ERC/double-wind maximum, material center-speed change, or new verified coastal-water observation; otherwise at 03:00 UTC / 11:00 PM ET.
- **Audit / Source Cutoff:** Baseline 20:46Z Sep 25; latest official complete NHC package 21Z Advisory/Discussion 21; latest decoded NOAA3 VDM through 22:11Z; dropsonde entry through 23:50Z; HDOB entry through 00:13:30Z Sep 26; live retrieval cutoff 00:35:45Z Sep 26 / 8:35:45 PM ET Sep 25.
