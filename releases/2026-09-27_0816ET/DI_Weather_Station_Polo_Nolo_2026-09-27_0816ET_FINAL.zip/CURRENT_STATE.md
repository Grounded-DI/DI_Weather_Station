# CURRENT STATE - DI Weather Station / Hurricane Polo

**Current evidence-state scan:** 2026-09-27 08:16 AM ET  
**Hard source cutoff:** 2026-09-27 12:05 UTC / 08:05 AM ET  
**Newest official Polo state used:** NHC Intermediate Advisory 27A, valid 12:00 UTC

- Storm ID: EP172026
- Official position: 20.7N, 113.7W
- Intensity: 120 mph at 12Z public advisory; 09Z complete advisory carried 105 kt
- Pressure: 952 mb
- Motion: 340 degrees / 10 mph
- Classification: Category 3
- Intensity trend: STABILIZED AFTER RAPID WEAKENING
- ERC: LIKELY / STRUCTURALLY SUPPORTED; NOT EXPLICITLY CONFIRMED
- ERC completion: UNRESOLVED
- Turn: NNW ESTABLISHED; N TURN PENDING
- <=7 kt slowdown trigger: NOT FIRED
- >=50 n mi right/east displacement trigger: NOT FIRED
- Baja west Hurricane Warning: ACTIVE
- Baja east Hurricane Warning: ACTIVE
- Mainland Mexico Hurricane Watch: ACTIVE
- Terrain hazard: ACTIVE
- Scenario A: CONTROLLING
- Scenario B: UNSUPPORTED
- Scenario C: ACTIVE SECONDARY
- Forecast-failure state: NO CENTRAL FORECAST FAILURE
- CFRI: NOT AUTHORIZED
- Newly resolved production-binding set: []
- Next full scan target: 15:10 UTC / approximately 11:10 AM ET

All earlier evidence states remain immutable.

Nolo / EP152026 is maintained in a separate evidence lane and is not merged into Polo CURRENT_STATE.
