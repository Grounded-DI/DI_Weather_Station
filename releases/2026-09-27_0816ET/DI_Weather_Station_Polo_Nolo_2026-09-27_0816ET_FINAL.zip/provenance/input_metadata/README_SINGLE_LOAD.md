# DI Weather Station — Hurricane Polo Single-Load Handoff

## Purpose
This ZIP is the single file to load for the next Hurricane Polo scan.

It contains:
1. The complete prior Enterprise-Safe v3 handoff contents.
2. The immutable 7:12 AM ET follow-up PDF.
3. The appended 12:31:26 PM ET full source-bound scan.
4. Current-state JSON and Markdown.
5. Original source lineage / visual evidence from the v3 handoff.
6. A regenerated package manifest and checksum ledger.

## Current evidence state
12:31:26 PM ET / 16:31:26 UTC — September 26, 2026.

## Continuity rule
Do not rewrite prior states. Append each new scan as a new evidence-state artifact and update only CURRENT_STATE.* and the package manifest/checksum ledger.

## Recommended next scan
21Z / 5:00 PM ET full source-bound scan unless a hard trigger fires earlier.
