# DI Weather Station — Hurricane Polo — Enterprise-Safe Rolling Handoff v3

## Single-package handoff status

**Use this ZIP as the sole rolling handoff package.** It supersedes the prior v2 ZIP for continuity purposes because it contains the preserved v2 payload plus the new 12:00 AM ET follow-up state.

### Current controlling evidence state
- Retrieval cutoff: **2026-09-26 04:01:47 UTC / 12:01:47 AM ET**
- NHC Advisory 22: **150 kt / 911 mb**
- Position: **17.4N 110.1W**
- Motion: **WNW 298° / 9 kt**
- ERC: **WATCH / PARTIAL — not confirmed**
- Baja watch/warning trigger: **FIRED — Hurricane Watch, Punta Eugenia southward to Santa Fe**
- Scenario: **A — controlling**
- CFRI: **NO RECALCULATION AUTHORIZED**
- +48 h CFRI: **UNRESOLVED**

See `CURRENT_STATE.md` first for the controlling state pointer.

## Immutable history preserved

1. **20:46 UTC / 4:46 PM ET Sep 25, 2026** — frozen baseline.
2. **00:35:45 UTC Sep 26 / 8:35:45 PM ET Sep 25, 2026** — frozen first follow-up.
3. **04:01:47 UTC / 12:01:47 AM ET Sep 26, 2026** — current controlling follow-up.

The original v2 PDF and the 8:35 PM follow-up Markdown are preserved byte-for-byte. No historical conclusion was rewritten.

## Package contents

- `CURRENT_STATE.md` — start here; latest controlling state and next trigger.
- `FOLLOWUP_SCAN_2026-09-26_0000ET.md` — complete 12:00 AM ET follow-up scan.
- `LIVE_SOURCE_REFERENCES_2026-09-26_0000ET.json` — audit pointers to the primary sources used in that scan.
- `DI_Weather_Station_Hurricane_Polo_ENTERPRISE_SAFE_v2.pdf` — preserved combined baseline + 8:35 PM rolling handoff.
- `FOLLOWUP_SCAN_2026-09-25_2030ET.md` — preserved 8:35 PM scan text.
- `SOURCE_LINEAGE.json` — immutable-state lineage, current pointer, parent package hash.
- `SHA256SUMS.txt` — SHA-256 hashes for every distributed file except itself.
- `visuals/` — preserved visual bundle from the prior package.

## Packaging / verification rule

The latest scan is packaged from the supplied scan text and the already-completed live-source run. **This packaging pass did not independently re-fetch weather sources.** Dynamic web endpoints may later update in place; the retrieval cutoff and evidence-state labels govern.

Preserve source-type distinctions:
- official sustained intensity ≠ raw flight-level / dropsonde / experimental near-surface measurements;
- forecast surge/coastal flooding ≠ observed water-level anomaly;
- IR appearance alone ≠ confirmed ERC;
- qualitative track language ≠ a manufactured displacement value.

## Future update rule

Do not rewrite prior states. Append the next scan as a new evidence state, update `CURRENT_STATE.md`, update `SOURCE_LINEAGE.json`, regenerate `SHA256SUMS.txt`, and issue a new handoff ZIP.

Parent v2 ZIP SHA-256: `754a50cf17bbd55bddb26e4f3bba27954ecab14b727ee0725ed70960b3279bc1`

## Enterprise-safe use boundary

This package is not an official NHC/NOAA warning, classification, or emergency-management directive. Use current official agency products and locally applicable emergency guidance for operational decisions.
