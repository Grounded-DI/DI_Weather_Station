# DI Weather Station — Hurricane Polo — 12:00 AM ET Follow-Up Scan

**FastPath / Protocol A / DI Weather Station**

**New live-source retrieval cutoff:** 04:01:47 UTC / 12:01:47 AM ET, Saturday, September 26, 2026.

The 20:46Z / 4:46 PM ET baseline and 00:35:45Z / 8:35:45 PM ET follow-up remain immutable historical states. The controlling prior handoff had Polo at 155 kt / 913 mb / 275° at 9 kt, ERC WATCH/PARTIAL, no Baja watch or warning, Scenario A controlling, and no CFRI recalculation authorized.

## Executive delta since 8:35 PM ET

The most important new development is not an intensity surprise; it is the first official Baja watch plus the beginning of the forecast turn.

At 03Z, NHC Advisory 22 analyzed Polo at **17.4°N 110.1°W, 150 kt / 175 mph, 911 mb, moving WNW at 298° / 9 kt**. That is a **5-kt decrease in official sustained intensity**, a **2-mb decrease in official pressure**, and a **23° clockwise change in the motion vector** from the 21Z state. A **Hurricane Watch is now in effect from Punta Eugenia southward to Santa Fe**.

This is the first source-supported evidence that the W → NW component is becoming observable, although a full NW→N transition is not yet established. The ≤7-kt slowdown trigger did not fire: the official speed remains 9 kt. NHC characterizes the new track as only slightly faster/farther north than the prior forecast, so there is no source basis for declaring a ≥50-n-mi right/east displacement.

The weakening transition has begun only in a narrow official-intensity sense: **155→150 kt**. It is not yet a clean structural weakening signal because pressure simultaneously fell from **913→911 mb**. The nearest prior official forecast anchor was **150 kt at 06Z**, so the 03Z analyzed intensity is **0 kt from that anchor**. The ≥15-kt DI intensity-deviation trigger is therefore **NOT FIRED**.

ERC remains **WATCH / PARTIAL**, not confirmed. NHC still treats ERC-related fluctuations as possible, but the new authoritative products do not document a concentric eyewall or a double wind maximum. Fresh GOES imagery was available through 03:05Z, but IR imagery alone does not meet the DI confirmation standard.

## New live-source matrix

| Source | Observation / valid time | Retrieval time | New source-bound state |
|---|---|---|---|
| NHC Public + Forecast Advisory 22 | 03:00Z Sep 26; issued ~02:55Z | Retrieved during 03:59:38–04:00:24Z | 17.4N 110.1W; 150 kt, 911 mb, WNW 298°/9 kt; Hurricane Watch Punta Eugenia→Santa Fe. |
| NHC Discussion 22 | 03Z cycle; issued ~02:56Z | 03:59:38–04:00:24Z | Aircraft: max flight-level wind 154 kt, NHC-equivalent ~140 kt at 10 m; experimental instrument ~80 m/s/155 kt at 25 m; higher instantaneous dropsonde gusts. NHC sets 1-min intensity at 150 kt. |
| NHC wind radii | 03Z | 03:59:38–04:00:24Z | 64 kt: 30/30/30/30 n mi; 50 kt: 50/50/40/40; 34 kt: 120/90/90/100 NE/SE/SW/NW. |
| NOAA/NESDIS/STAR GOES floater | Latest image observation 03:05Z | 03:59:38–04:00:24Z | Fresh satellite imagery available; no authoritative concentric-eyewall/double-max diagnosis supplied by the retrieved STAR text. |
| NOAA/AOML field-data registry | Current retrieval | 03:59:38–04:00:24Z | AOML states most posted mission data are Level-2 QC; the retrieved Polo listing did not expose a newer Sep-25/26 Level-2 mission dataset. A separately recovered fresh QC file is therefore UNRESOLVED. |
| NHC Wind Probabilities 22 | 03Z | 04:00:24–04:01:47Z | Loreto 74/35/14% cumulative ≥34/50/64 kt; Guaymas 68/30/13%; La Paz 9% ≥34 kt. |
| NHC rainfall / surge | 03Z | 03:59:38–04:00:24Z | Baja storm total remains 4–8 in, max 10 in; explicit surge/coastal-flooding forecast now included. |
| Mexico SMN/CONAGUA | Issued Sep 25; multi-day forecast | 04:00:24–04:01:47Z | Later-period forecast highlights north/central BCS with 75–150 mm rainfall, plus elevated seas/wind; different time window from NHC storm-total product. |

## Source concordance / conflicts

**Official sustained intensity vs spectacular raw measurements:** no conflict once measurement type is preserved. NHC’s 150-kt value is the operational 1-minute sustained analysis. The 154-kt flight-level maximum, ~155-kt experimental 25-m measurement, and higher instantaneous dropsonde winds are not interchangeable with a 1-minute 10-m sustained wind. NHC explicitly accounted for the non-standard research pattern when setting 150 kt.

**Pressure vs wind:** official pressure fell 2 mb while official wind fell 5 kt. That means the new cycle is not a simple monotonic “pressure rising = storm weakening” transition. It is consistent with inner-core reorganization/fluctuation and is one reason the weakening diagnosis remains early rather than fully established.

**Track language:** the quantified motion is now WNW 298°, while Discussion 22 describes Polo as having continued generally westward and still forecasts a gradual northwest turn. The numerical motion vector is treated as evidence that the turn has started, but not that the full northward turn is established.

**Rainfall:** NHC’s 4–8/max-10-in storm-total envelope is unchanged. Mexico’s SMN later-period product places significant rainfall over north/central Baja California Sur, but because its accumulation period and product definition differ, that is not sufficient to claim a like-for-like NHC rainfall-axis shift.

## Storm-physics / ERC diagnosis

**ERC status: WATCH / PARTIAL — maintain. Do not clear. Do not confirm.**

The 8:35 PM handoff elevated the state because aircraft indicated possible early ERC development. Advisory 22 continues to mention intensity fluctuations from an ERC, but the hard DI confirmation requirement remains unmet: **no recovered primary product explicitly shows a concentric eyewall, double wind maximum, or equivalent definitive structural signature.**

The current official eye diameter is **UNRESOLVED**. Advisory 21 explicitly reported 15 n mi; Advisory 22 does **not** carry an eye-diameter field. The 15-n-mi value is not silently propagated into the 03Z state. The current measurable core envelope is represented by the 64-/50-/34-kt radii above.

## Rapid-change analysis

From the authoritative 21Z state to 03Z:

| Variable | 21Z | 03Z | Delta |
|---|---:|---:|---:|
| Max sustained wind | 155 kt | 150 kt | −5 kt |
| Official pressure | 913 mb | 911 mb | −2 mb |
| Motion | 275° / 9 kt | 298° / 9 kt | +23° clockwise; speed unchanged |
| Eye diameter | 15 n mi | UNRESOLVED | No valid current comparison |
| 34-kt radii | 120/90/90/100 | 120/90/90/100 | No change |
| 50-kt radii | 50/50/40/40 | 50/50/40/40 | No change |
| 64-kt radii | 30/30/25/30 | 30/30/30/30 | SW +5 n mi only |

The new wind field therefore looks more like **minor inner-core redistribution/reorganization** than broad expansion or collapse.

Against the original 15Z baseline, Polo is now 5 kt weaker, 11 mb higher in official pressure, moving 28° farther clockwise, and has a broader tropical-storm-force envelope than the original baseline in the NE/SW quadrants. The prior historical conclusions remain unchanged.

## Track / speed / turn analysis

**Turn test: WATCH → observable initial turn.** The official motion changed from W/275° to WNW/298°. This is the first clean numerical evidence in the official advisory vector that the forecast W→NW evolution is beginning. Full NW→N evolution remains ahead.

**Slowdown test: NOT FIRED.** 21Z = 9 kt; 03Z = 9 kt. The DI condition requires ≤7 kt on two successive fixes.

**≥50-n-mi right/east Baja displacement: NOT FIRED.** NHC says the track was adjusted slightly faster and farther north, while remaining generally similar to the previous advisory. No authoritative quantified ≥50-n-mi right/east displacement was recovered, and none is manufactured here.

## Geographic corridor update

**Socorro / offshore:** remains the immediate marine/wind corridor. Advisory 22 gives Isla Socorro a 96% cumulative probability of ≥34 kt during the current five-day probability window, though the higher thresholds are much lower in the forward-looking window.

**Los Cabos:** still does not become the principal direct-wind corridor merely because Baja is now under a watch elsewhere. Cabo San Lucas and San José del Cabo are absent from the Advisory-22 wind-probability table; under NHC’s display rules that means their five-day cumulative ≥34-kt probability is below the 3% reporting threshold. Surf, rainfall, logistics and coastal flooding remain separate hazards.

**Central/eastern Baja:** the north/east migration signal is stronger. Loreto is now **74% ≥34 kt, 35% ≥50 kt, 14% ≥64 kt**; La Paz is only **9% ≥34 kt**. The direct-wind gradient therefore remains markedly stronger farther north than La Paz/Cabo.

**Western Baja watch corridor:** operationally escalated. The Hurricane Watch from **Punta Eugenia southward to Santa Fe** is the first hard watch-state change since the 8:35 PM handoff.

**Gulf of California / western mainland Mexico:** materially more important later. Guaymas is now **68% ≥34 kt, 30% ≥50 kt, 13% ≥64 kt** in the Advisory-22 table. That is a stronger downstream direct-wind signal than the earlier handoff could source-lock.

## Rainfall / terrain / coastal-water update

**Rainfall trigger: NOT FIRED.** NHC still carries **4–8 inches with maxima of 10 inches** over portions of Baja California Sur. The >10-in trigger has not fired.

**Heavy-rain axis:** strict like-for-like migration is **UNRESOLVED**. Mexico’s SMN later-period forecast does specifically emphasize **north and central Baja California Sur** for intense rainfall, which is consistent with northward corridor migration, but it is a different product/time accumulation and cannot be substituted for a revised NHC storm-total axis.

**Coastal-water trigger: NOT FIRED; measured state remains UNRESOLVED.** Advisory 22 now explicitly forecasts the possibility of significant storm-surge coastal flooding with destructive waves. That is new forecast language, but no verified Polo-attributable tide anomaly, measured inundation, or coastal residence observation was recovered by cutoff. Forecast surge does not satisfy the DI measured-water trigger.

## DI trigger matrix

| Trigger | State | Determination |
|---|---|---|
| ≥15-kt intensity deviation | NOT FIRED | 03Z 150 kt equals nearest prior official 06Z forecast anchor of 150 kt. |
| Weakening transition | WATCH / EARLY | Official wind −5 kt, but pressure −2 mb; transition is detectable but not yet structurally clean. |
| ERC concentric eyewall / double maximum | WATCH | Possible ERC remains; hard structural evidence not recovered. |
| ≤7 kt on two successive fixes | NOT FIRED | 9 kt → 9 kt. |
| ≥50 n mi right/east Baja displacement | NOT FIRED | Only slight faster/farther-north adjustment documented. |
| Baja tropical watch/warning | FIRED | Hurricane Watch issued Punta Eugenia→Santa Fe. |
| Rainfall >10 in / terrain escalation | NOT FIRED | Envelope remains 4–8 / max 10 in. |
| Verified coastal-water anomaly | NOT FIRED | No measured Polo-attributable anomaly recovered. |
| CFRI ≥25-point change / credible bound ≥175 | UNRESOLVED | Required production inputs still absent. |

## Scenario A/B/C determination

**Scenario A remains controlling — independently revalidated, not merely preserved.**

The evidence now fits A better in two important respects: official intensity has started edging down toward the prior forecast trajectory, and the west-to-northwest turn has become visible. The Hurricane Watch is also consistent with the previously anticipated escalation of Baja operational exposure.

Scenario B is **not** required. Polo is not stronger than forecast, has not slowed to the DI threshold, and no ≥50-n-mi right/east displacement or observed prolonged coastal residence exists.

Scenario C is also **not** required. The 5-kt weakening and ERC watch are C-side signals, but there is still no confirmed ERC, no rapid structural collapse, and no source-supported faster/left track away from the Baja corridor.

## Forecast-failure test

| Prior forecast condition | Current result |
|---|---|
| Extreme intensity holds briefly, then weakening begins | SURVIVED / beginning to verify. Official intensity is down 5 kt. |
| Renewed strengthening above 155 kt would challenge forecast | DID NOT OCCUR. |
| Weakening timing completely fails if Polo stays near/above peak into principal Saturday test window | NOT YET FAILED; principal window not reached. |
| W→NW→N turn develops | SURVIVED; first WNW component now observable. |
| Slowdown materially increases residence | NOT PRESENT. |
| Baja watch could be required | SURVIVED / VERIFIED. Hurricane Watch issued. |
| Rainfall remains 4–8/max 10 | SURVIVED. |
| No confirmed coastal-water residence yet | SURVIVED / still unresolved. |
| Possible ERC could alter intensity distribution | WEAKENED ASSUMPTION remains on WATCH, not confirmed. |

**Forecast failure state: NO central forecast failure.**

## CFRI determination

**NO RECALCULATION AUTHORIZED.**

The Hurricane Watch fires an enterprise decision trigger, but it does **not** supply the missing FTA/SMRB/SDRL production inputs. There is still no verified coastal-water loading/residence measurement; rainfall has not breached the existing envelope; the slowdown trigger has not fired; and no new coefficients are source-bound.

The historical CFRI values therefore remain locked. **+48 h remains UNRESOLVED.**

## Biggest remaining uncertainty

The largest meteorological uncertainty has shifted from “is the turn beginning?” to **inner-core structural evolution: whether the ERC signal becomes physically confirmed and whether the 150-kt analysis is the start of sustained weakening or another intensity fluctuation.**

For compound risk, the largest unresolved variable remains **actual coastal-water residence/loading**.

## Highest-value next observation

A **fresh microwave or aircraft structural pass capable of resolving concentric eyewalls / a second wind maximum**, paired with representative low-level surface-wind data. That would directly settle the ERC state and determine whether the current 5-kt intensity decline is structural or transient.

## Next decision trigger

**Immediate:** any Hurricane Watch upgrade to Hurricane Warning or Tropical Storm Warning, confirmed concentric eyewall/double-wind maximum, ≤7-kt motion on successive fixes, or first verified Polo-attributable coastal-water anomaly.

The already-issued Hurricane Watch is itself a **FIRED DI trigger** and should be treated as the controlling official hazard-status change.

## Next recalculation time

**Full scheduled scan: 09:00 UTC / 5:00 AM ET, Saturday, September 26 — NHC Advisory/Discussion 23.**

An intermediate advisory is scheduled for **06Z / 2:00 AM ET**; it warrants an immediate state check for warning/intensity/position changes but, absent a trigger, not a full CFRI rebuild.

## Full audit / source cutoff block

**Historical state 1:** 20:46Z Sep 25 / 4:46 PM ET — immutable baseline.

**Historical state 2:** 00:35:45Z Sep 26 / 8:35:45 PM ET Sep 25 — immutable follow-up.

**New retrieval window:** approximately 03:59:38Z–04:01:47Z Sep 26.

**Hard retrieval cutoff:** **04:01:47 UTC / 12:01:47 AM ET.**

**Newest complete NHC state used:** Advisory / Forecast Advisory / Discussion / Wind Probabilities **22, valid 03Z Sep 26**.

**Newest later-timestamp satellite evidence recovered:** NOAA/NESDIS/STAR GOES imagery through **03:05Z**; used only as fresh imagery availability, **not** as an ERC-confirmation source.

**Recon rule:** NHC’s operational aircraft synthesis governs the current intensity assessment. No separately recoverable newer Level-2 QC Polo mission file was promoted. Raw/experimental aircraft values were retained with altitude, duration and measurement limitations.

**Unresolved at cutoff:** current eye diameter; definitive ERC topology; separately published fresh Level-2 QC inner-core dataset; verified Polo-attributable tide/surge/inundation measurement; production SDRL/coastal-residence input; +48-h CFRI.

## What did we learn at 11:55 PM that we did not know at 8:35 PM?

- A **Hurricane Watch** has been issued for part of Baja California Sur.
- Polo’s official state changed to **150 kt / 911 mb / WNW 298° at 9 kt**: slight wind weakening, slight pressure deepening, and the first clear numerical W→WNW turn signal.
- Fresh NHC aircraft synthesis supports **150 kt**, while the more spectacular flight-level, dropsonde and experimental near-surface measurements still do **not** replace the official sustained intensity.
- The 34-/50-kt wind field is essentially unchanged; only the SW 64-kt radius increased 5 n mi.
- The newly recoverable Advisory-22 probability table sharply emphasizes **Loreto and Guaymas** as later direct-wind corridors, while the ERC remains **WATCH / PARTIAL**, rainfall remains **4–8/max 10 in**, and no measured coastal-water trigger has fired.
