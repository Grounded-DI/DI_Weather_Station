# Hurricane Polo — eight scientific and auditability visuals

Historical report cutoff: September 25, 2026, 20:46 UTC. Weather values reproduce the supplied report; underlying weather sources were not independently verified. Images are 3840 × 2400 pixels.

The first illustration was created with built-in image generation, then exact text was composited with Matplotlib. Charts and diagrams were rendered programmatically. Map boundaries: Natural Earth 1:50m, https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_50m_admin_0_countries.geojson. Location markers are approximate WGS84 city/island centers.

## 01_extreme_core.png

Reported intensity and satellite presentation frame a conceptual illustration of Polo’s compact core.

**Alt text:** Conceptual hurricane cutaway alongside report-supplied 155 kt winds, 900 mb pressure, a 20-nautical-mile eye, and satellite eye and cloud-top temperatures.

## 02_rapid_strengthening.png

Wind increased as pressure fell sharply between 0900 and 1500 UTC.

**Alt text:** Aligned plots show 130, 140, and 155 kt winds and 935, 929, and 900 mb pressures at 0300, 0900, and 1500 UTC. Six-hour changes are plus 15 kt and minus 29 mb.

## 03_wind_geography.png

The report’s five-day wind probabilities emphasize Socorro offshore and Loreto within Baja.

**Alt text:** Regional map with numbered markers and bars: Socorro approximately 81 percent, Cabo San Lucas 4, San José del Cabo 4, La Paz 19, Loreto 63, and Guaymas approximately 30 percent for winds at least 34 kt.

## 04_intensity_and_exposure.png

Official forecast winds decline while the report identifies a later potential compound-impact problem for Baja.

**Alt text:** Wind forecast falls from 155 to 110 kt over four anchors. Adjacent schematic links turn timing, terrain rainfall, and coastal residence to potential impacts; rainfall is 4–8 inches with isolated 10-inch maxima.

## 05_evidence_clock.png

The report preserves the age of each evidence stream and separates bulletin issuance from observation time.

**Alt text:** Timeline shows SAR at 0110, microwave at 0905, NHC state at 1500, marine publication at 1605 using 1500 imagery, a 2046 cutoff, and the scheduled 2100 package beyond it. Aircraft results remain unrecovered.

## 06_compound_risk.png

Discrete reconstructed ranges end at +24 hours, with the +48-hour state deliberately uncalculated.

**Alt text:** Range plot shows low, central, and high CFRI scenarios: current 8.2/22.0/48.8, plus 6 hours 8.2/22.5/49.0, plus 12 hours 15.3/34.7/69.5, plus 24 hours 24.5/55.1/110.7. Plus 48 hours is unresolved.

## 07_information_value.png

The report assigns different qualitative value to evidence for storm state, path, compound risk, and decisions.

**Alt text:** Six-row qualitative matrix. Aircraft data has very high physical-state value; center fixes very high path and decision value; coastal gauges very high compound-risk and local decision value. No numerical scores are assigned.

## 08_forecast_revision.png

Four explicit evidence paths identify which forecast conclusions require revision.

**Alt text:** Branching revision diagram: renewed strengthening revises intensity, persistent peak intensity challenges weakening timing, altered motion revises corridor and residence, and coastal observations replace a proxy. This is documented logic, not proof of executed gates.

