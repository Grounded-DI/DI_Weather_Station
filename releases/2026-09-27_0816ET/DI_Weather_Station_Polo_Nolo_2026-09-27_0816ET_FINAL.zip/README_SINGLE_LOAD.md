# Single-load instructions

Read `README.md`, then `CURRENT_STATE.md`. The controlling packaged scan is September 27, 2026, 08:16 AM ET, with a 12:05 UTC source cutoff. The complete four-PDF inventory and separate Nolo lane are documented in `README.md`.
