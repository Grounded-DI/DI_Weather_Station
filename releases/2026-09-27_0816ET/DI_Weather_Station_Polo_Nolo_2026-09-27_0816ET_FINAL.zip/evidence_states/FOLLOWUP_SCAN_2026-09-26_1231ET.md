# Hurricane Polo — 12:31:26 PM ET Full Source-Bound Scan

FastPath / Protocol A / DI Weather Station  
Date: 2026-09-26  
Hard retrieval cutoff: 16:31:26 UTC / 12:31:26 PM ET

## Prior immutable comparison state — 7:12 AM ET / 09Z
- Center: 17.6°N, 111.0°W
- Intensity: 145 kt / 165 mph
- Pressure: 917 mb
- Motion: 290° / 8 kt
- Eye: 5 n mi
- ERC: WATCH / PARTIAL — NOT CONFIRMED
- Weakening: EARLY / MIXED
- Scenario: A — CONTROLLING

## Current 15Z official state
- Center: 17.9°N, 111.7°W
- Intensity: 135 kt / 155 mph
- Pressure: 928 mb
- Motion: 295° / 8 kt
- Classification: Category 4
- Current eye diameter: UNRESOLVED
- ERC confirmation: NOT FIRED
- Weakening: ESTABLISHED — DI WEATHER INFERENCE
- Scenario A: CONTROLLING
- Scenario C: strengthened secondary signal
- Scenario B: unsupported
- CFRI recalculation: NOT AUTHORIZED
- CFRI +48 h: UNRESOLVED

## Material delta since 7:12 AM ET
- Wind: 145 → 135 kt (-10 kt)
- Pressure: 917 → 928 mb (+11 mb)
- Motion heading: 290° → 295°
- Forward speed: 8 → 8 kt
- NHC structural description: eye cloud-filled; increasing shear implicated
- Objective intensity estimates: approximately 125–142 kt
- NHC 135-kt estimate described as potentially slightly generous
- Sustained weakening advanced from EARLY/MIXED to ESTABLISHED
- Turn signal progressed modestly but was not established
- Wind radii remained essentially unchanged
- No new broadening signal supported an advanced ERC

## Current wind radii
- 64 kt NE/SE/SW/NW: 30 / 30 / 25 / 30 n mi
- 50 kt NE/SE/SW/NW: 50 / 50 / 40 / 40 n mi
- 34 kt NE/SE/SW/NW: 110 / 80 / 90 / 100 n mi

## Source-bound matrix
| Source | Valid/source time | State |
|---|---|---|
| NHC Forecast Advisory 24 | 1500Z; issued 1449Z | 17.9N 111.7W; 135 kt; 928 mb; 295°/8 kt; Cat 4 |
| NHC Discussion 24 | 15Z; issued 1451Z | Eye cloud-filled; increasing shear implicated; objective estimates ~125–142 kt; weakening favored |
| NHC Public Advisory 24 | 1500Z; issued 1450Z | Hurricane Watch Punta Eugenia–Santa Fe unchanged; east-coast Baja watches likely later; rain 4–8 in, max 10 |
| NHC Wind Probabilities 24 | 1500Z | Loreto 74/31/11%; La Paz 10% >=34 kt; P. Abreojos 31/5/2%; Guaymas 43/11/3%; Socorro 99% >=34 kt, 3% >=50 kt |
| GOES / NOAA STAR | latest recovered 1555Z | Current imagery recovered through 15:55Z |
| NOAA/AOML HFP registry | checked through cutoff | Newer Sep25/26 Level-2 mission not recovered |
| NOAA STAR SAR | 13:12Z acquisition slot | Processed Sep26 scene not recovered |
| Fresh microwave | searched through cutoff | UNRESOLVED |
| SMN / CONAGUA | current forecast context | BCS / NW Mexico heavy-rain context; accumulation windows kept separate |
| Measured coastal water | searched through cutoff | No verified Polo-attributable water-level/inundation measurement recovered |

## DI trigger matrix
| Trigger | State |
|---|---|
| >=15-kt intensity deviation | NOT FIRED |
| Sustained weakening | FIRED / ESTABLISHED — DI WEATHER INFERENCE |
| Confirmed ERC | NOT FIRED |
| <=7 kt on two successive fixes | NOT FIRED |
| >=50 n mi right/east displacement | NOT FIRED |
| New/upgraded Baja watch/warning | NOT FIRED this cycle |
| Official rainfall max >10 in | NOT FIRED |
| Terrain-axis escalation | WATCH |
| Verified coastal-water anomaly | NOT FIRED / UNRESOLVED |
| CFRI recalculation | NOT AUTHORIZED |

## Track / corridor disposition
TURN WATCH — PROGRESSING, NOT ESTABLISHED.

Enterprise corridor remains:
western Baja approach → central/northern Baja crossing → Loreto/Gulf side → northwestern mainland Mexico.

Loreto remains the strongest named eastern-Baja direct-wind signal in this evidence state. Guaymas direct-wind probabilities eased versus the 7:12 AM state.

## Scenario determination
Scenario A remains controlling because the central mechanism remains intact: physical intensity is weakening while geographic exposure to Baja increases.

Scenario C strengthened as a secondary signal because shear-driven weakening arrived more clearly and earlier, but it did not displace Scenario A.

Scenario B remains unsupported.

## Forecast-failure state
NO CENTRAL FORECAST FAILURE.

The main revision is timing: sustained weakening became established earlier than the 7:12 AM interpretation indicated. The W→NW→N forecast remained viable; 295° represented modest turn progression, not completion. The slowdown trigger remained unfired.

## CFRI
NO RECALCULATION AUTHORIZED. +48 h remains UNRESOLVED.

No verified Polo-attributable coastal-water loading/residence measurement, newly authorized FTA/SMRB coefficient, or other production CFRI input became source-bound.

## Highest-value next observations
1. Fresh aircraft vortex/core pass: pressure, SFMR/surface-equivalent wind, RMW, eyewall topology, secondary wind maximum.
2. Processed product from the 13:12Z SAR acquisition.
3. Successive center fixes and next official watch package.
4. Verified Polo-attributable coastal-water observation.

## Next triggers / cadence
Immediate rescan on:
- east-coast Baja watch/warning issuance
- NW mainland watch
- <=7 kt on two consecutive fixes
- confirmed concentric eyewall / double wind maximum
- >=15-kt official intensity departure
- >=50-n-mi right/east track displacement
- NHC rainfall maximum >10 in
- first verified Polo-attributable coastal-water measurement

Recommended:
- 18Z / 2:00 PM ET state check
- 21Z / 5:00 PM ET full source-bound scan
- earlier if a hard trigger fires

## Evidence-handling rule
Prior evidence states are immutable. This scan appends a new state and does not rewrite prior conclusions.
UNRESOLVED remains unresolved where a primary source was not recovered.
